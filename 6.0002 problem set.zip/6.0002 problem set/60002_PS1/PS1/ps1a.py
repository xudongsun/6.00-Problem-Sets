###########################
# 6.0002 Problem Set 1a: Space Cows 
# Name: Xudong Sun
# Collaborators: NA
# Time: 2:00

from ps1_partition import get_partitions
import time

#================================
# Part A: Transporting Space Cows
#================================

# Problem 1
def load_cows(filename):
    """
    Read the contents of the given file.  Assumes the file contents contain
    data in the form of comma-separated cow name, weight pairs, and return a
    dictionary containing cow names as keys and corresponding weights as values.

    Parameters:
    filename - the name of the data file as a string

    Returns:
    a dictionary of cow name (string), weight (int) pairs
    """
    # open the file in read mode
    f = open(filename, 'r')
    dict_cow = {}
    # for every line in the file, split the line with the comma, use the name as the key and the
    for line in f:
        name,weight = line.split(',')
        dict_cow[name] = int(weight)
    return dict_cow

    

# Problem 2
def greedy_cow_transport(cows,limit=10):
    """
    Uses a greedy heuristic to determine an allocation of cows that attempts to
    minimize the number of spaceship trips needed to transport all the cows. The
    returned allocation of cows may or may not be optimal.
    The greedy heuristic should follow the following method:

    1. As long as the current trip can fit another cow, add the largest cow that will fit
        to the trip
    2. Once the trip is full, begin a new trip to transport the remaining cows

    Does not mutate the given dictionary of cows.

    Parameters:
    cows - a dictionary of name (string), weight (int) pairs
    limit - weight limit of the spaceship (an int)
    
    Returns:
    A list of lists, with each inner list containing the names of cows
    transported on a particular trip and the overall list containing all the
    trips
    """
    result = []
    selected = []
    # sort the dictionary according to the value, we get a list of tuples
    lt_cows = sorted(cows.copy().items(), key = lambda d:d[1], reverse = True)
    # greedy algorithm until all the cows are transported
    while len(selected) < len(lt_cows):
        one_ship = []
        weight = 0.0
        for cow in lt_cows:
            if (cow[1] + weight) <= limit and cow[0] not in selected:
                weight += cow[1]
                one_ship.append(cow[0])
                selected.append(cow[0])
                
        result.append(one_ship)
        
    return result
    
            
    

# Problem 3
def brute_force_cow_transport(cows,limit=10):
    """
    Finds the allocation of cows that minimizes the number of spaceship trips
    via brute force.  The brute force algorithm should follow the following method:

    1. Enumerate all possible ways that the cows can be divided into separate trips 
        Use the given get_partitions function in ps1_partition.py to help you!
    2. Select the allocation that minimizes the number of trips without making any trip
        that does not obey the weight limitation
            
    Does not mutate the given dictionary of cows.

    Parameters:
    cows - a dictionary of name (string), weight (int) pairs
    limit - weight limit of the spaceship (an int)
    
    Returns:
    A list of lists, with each inner list containing the names of cows
    transported on a particular trip and the overall list containing all the
    trips
    """
    result = []
    d_cows = cows.copy()
    # for every partition, check if every trip in this partition is not over the limit
    for partition in get_partitions(list(d_cows.keys())):
        valid = True
        for ship in partition:
            # if at least one of the trips is over the limit, the partition is invalid
            if sum([d_cows[cow] for cow in ship]) > limit:
                valid = False
        # put every valid partition into the result list
        if valid:
            result.append(partition)
    # sort the list by the lenth of elements(list), the first element will be 
    # the partition with minimum number of trips
    return sorted(result, key = lambda l: len(l))[0]
                
        
# Problem 4
def compare_cow_transport_algorithms():
    """
    Using the data from ps1_cow_data.txt and the specified weight limit, run your
    greedy_cow_transport and brute_force_cow_transport functions here. Use the
    default weight limits of 10 for both greedy_cow_transport and
    brute_force_cow_transport.
    
    Print out the number of trips returned by each method, and how long each
    method takes to run in seconds.

    Returns:
    Does not return anything.
    """
    filename = 'ps1_cow_data.txt'
    cows = load_cows(filename)
    
    print('Testing greedy algorithm...')
    start1 = time.perf_counter()
    greedy = greedy_cow_transport(cows,limit=10)
    end1 = time.perf_counter()
    print('The number of trips found by greedy algorithm:')
    print(len(greedy))
    print('The result of the algorithm:')
    print(greedy)
    print('Running time:')
    print(end1-start1)
    # round the number, if necessary
    print('or: ')
    print('%.015f'%(end1-start1))
    
    print('Testing brute force algorithm...')
    start2 = time.perf_counter()
    brute = brute_force_cow_transport(cows,limit=10)
    end2 = time.perf_counter()
    print('The number of trips found by brute force algorithm:')
    print(len(brute))
    print('The result of the algorithm:')
    print(brute)
    print('Running time:')
    print(end2-start2)
    
# the test command    
if __name__ == '__main__':
     compare_cow_transport_algorithms() 
    
    
    
    
    
    
